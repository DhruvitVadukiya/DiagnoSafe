The project consists of the following folders:

DATASET : consists of all the datasets which are used for training the Machine Learning Models.

TRAINED MODELS: consists of all the trained models which are ready to use.

NOTEBOOKS: consists of pyhton notebooks which contain the preprocessing as well as performance measures of the machine learning models.

DIAGNOSAFE: This folder consists of all the php(Laravel) and HTML CSS code. This code is responsible for serving the WebApp.

FLASK: contains the flask file used to connect website to Machine Learning Models.


NOTE:- To run the project successfully, you are required to have php,pyton,flask and MySQL installed in your Desktop.
